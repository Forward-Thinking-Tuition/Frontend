<!DOCTYPE html>
<html lang="en-US">

<head>
		<meta charset="UTF-8" />
	<!-- wp_head -->
	
	<!-- This site is optimized with the Yoast SEO plugin v15.3 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Forward Thinking Science | Tuition Centre</title>
	<meta name="description" content="Forward Thinking (FT) is the first dedicated science tuition centre in Scotland. The goal of FT is to help students develop a critical mindset and re-engage with the sciences. We provide tuition in Biology, Chemistry and Physics at national 5 and higher level." />
	<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
	<link rel="canonical" href="http://www.forwardthinkingscience.co.uk/" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="Forward Thinking Science | Tuition Centre" />
	<meta property="og:description" content="Forward Thinking (FT) is the first dedicated science tuition centre in Scotland. The goal of FT is to help students develop a critical mindset and re-engage with the sciences. We provide tuition in Biology, Chemistry and Physics at national 5 and higher level." />
	<meta property="og:url" content="http://www.forwardthinkingscience.co.uk/" />
	<meta property="og:site_name" content="Forward Thinking" />
	<meta property="article:publisher" content="https://www.facebook.com/forwardthinkingscience/" />
	<meta property="article:modified_time" content="2020-02-26T13:12:24+00:00" />
	<meta property="og:image" content="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/01/ft-Scotland-light-tran-7-1024x634-500x309.png" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:label1" content="Written by">
	<meta name="twitter:data1" content="admin">
	<meta name="twitter:label2" content="Est. reading time">
	<meta name="twitter:data2" content="2 minutes">
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"http://www.forwardthinkingscience.co.uk/#organization","name":"Forward Thinking Science","url":"http://www.forwardthinkingscience.co.uk/","sameAs":["https://www.facebook.com/forwardthinkingscience/","https://www.instagram.com/forwardthinkingscience/"],"logo":{"@type":"ImageObject","@id":"http://www.forwardthinkingscience.co.uk/#logo","inLanguage":"en-US","url":"http://www.forwardthinkingscience.co.uk/wp-content/uploads/2018/12/ft-Icon-dark.png","width":2001,"height":2014,"caption":"Forward Thinking Science"},"image":{"@id":"http://www.forwardthinkingscience.co.uk/#logo"}},{"@type":"WebSite","@id":"http://www.forwardthinkingscience.co.uk/#website","url":"http://www.forwardthinkingscience.co.uk/","name":"Forward Thinking","description":"Helping Students Re-Engage With Science","publisher":{"@id":"http://www.forwardthinkingscience.co.uk/#organization"},"potentialAction":[{"@type":"SearchAction","target":"http://www.forwardthinkingscience.co.uk/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"en-US"},{"@type":"ImageObject","@id":"http://www.forwardthinkingscience.co.uk/#primaryimage","inLanguage":"en-US","url":"http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/01/ft-Scotland-light-tran-7.png","width":2001,"height":1239},{"@type":"WebPage","@id":"http://www.forwardthinkingscience.co.uk/#webpage","url":"http://www.forwardthinkingscience.co.uk/","name":"Forward Thinking Science | Tuition Centre","isPartOf":{"@id":"http://www.forwardthinkingscience.co.uk/#website"},"about":{"@id":"http://www.forwardthinkingscience.co.uk/#organization"},"primaryImageOfPage":{"@id":"http://www.forwardthinkingscience.co.uk/#primaryimage"},"datePublished":"2018-12-25T17:01:23+00:00","dateModified":"2020-02-26T13:12:24+00:00","description":"Forward Thinking (FT) is the first dedicated science tuition centre in Scotland. The goal of FT is to help students develop a critical mindset and re-engage with the sciences. We provide tuition in Biology, Chemistry and Physics at national 5 and higher level.","inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["http://www.forwardthinkingscience.co.uk/"]}]}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Forward Thinking &raquo; Feed" href="http://www.forwardthinkingscience.co.uk/feed/" />
<link rel="alternate" type="application/rss+xml" title="Forward Thinking &raquo; Comments Feed" href="http://www.forwardthinkingscience.co.uk/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.forwardthinkingscience.co.uk\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.3"}};
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style>
	.themify_builder .wow { visibility: hidden; }
	div:not(.caroufredsel_wrapper) > .themify_builder_slider > li:not(:first-child), .mfp-hide { display: none; }
a.themify_lightbox, .module-gallery a, .gallery-icon, .themify_lightboxed_images .post a[href$="jpg"], .themify_lightboxed_images .post a[href$="gif"], .themify_lightboxed_images .post a[href$="png"], .themify_lightboxed_images .post a[href$="JPG"], .themify_lightboxed_images .post a[href$="GIF"], .themify_lightboxed_images .post a[href$="PNG"], .themify_lightboxed_images .post a[href$="jpeg"], .themify_lightboxed_images .post a[href$="JPEG"] { cursor:not-allowed; }
	.themify_lightbox_loaded a.themify_lightbox, .themify_lightbox_loaded .module-gallery a, .themify_lightbox_loaded .gallery-icon { cursor:pointer; }
	</style><style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='sb_instagram_styles-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=2.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='themify-common-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/themify/css/themify.common.min.css?ver=4.8.1' type='text/css' media='all' />
<meta name="themify-framework-css" data-href="http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/themify/css/themify.framework.min.css?ver=4.8.1" content="themify-framework-css" id="themify-framework-css" /><meta name="builder-styles-css" data-href="http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/themify/themify-builder/css/themify-builder-style.min.css?ver=4.8.1" content="builder-styles-css" id="builder-styles-css" />
<link rel='stylesheet' id='wp-block-library-css'  href='http://www.forwardthinkingscience.co.uk/wp-includes/css/dist/block-library/style.min.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='export-wp-page-to-static-html-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/plugins/export-wp-page-to-static-html/public/css/export-wp-page-to-static-html-public.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='wp-v-icons-css-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/plugins/wp-visual-icon-fonts/css/wpvi-fa4.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='theme-style-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/style.min.css?ver=2.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='themify-media-queries-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/media-queries.min.css?ver=2.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='ultra-header-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/styles/header-horizontal.min.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='ultra-color-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/styles/theme-color-black.min.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='themify-builder-27-generated-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/uploads/themify-css/themify-builder-27-generated.css?ver=1582722744' type='text/css' media='all' />
<link rel='stylesheet' id='themify-customize-css'  href='http://www.forwardthinkingscience.co.uk/wp-content/uploads/themify-customizer.css?ver=19.07.23.14.41.17' type='text/css' media='all' />
<link rel='stylesheet' id='themify-google-fonts-css'  href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,700italic,400,300,600,700&#038;subset=latin' type='text/css' media='all' />
		<script>
			/* <![CDATA[ */
			var rcewpp = {
				"ajax_url":"http://www.forwardthinkingscience.co.uk/wp-admin/admin-ajax.php",
				"nonce": "6e50bfd395",
				"home_url": "http://www.forwardthinkingscience.co.uk"
			};
			/* ]]\> */
		</script>
		<script type='text/javascript' src='http://www.forwardthinkingscience.co.uk/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp' id='jquery-core-js'></script>
<script type='text/javascript' src='http://www.forwardthinkingscience.co.uk/wp-content/plugins/export-wp-page-to-static-html/public/js/export-wp-page-to-static-html-public.js?ver=1.0.0' id='export-wp-page-to-static-html-js'></script>
<link rel="https://api.w.org/" href="http://www.forwardthinkingscience.co.uk/wp-json/" /><link rel="alternate" type="application/json" href="http://www.forwardthinkingscience.co.uk/wp-json/wp/v2/pages/27" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.forwardthinkingscience.co.uk/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.forwardthinkingscience.co.uk/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.5.3" />
<link rel='shortlink' href='http://www.forwardthinkingscience.co.uk/' />
<link rel="alternate" type="application/json+oembed" href="http://www.forwardthinkingscience.co.uk/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.forwardthinkingscience.co.uk%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://www.forwardthinkingscience.co.uk/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.forwardthinkingscience.co.uk%2F&#038;format=xml" />


<link href="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2018/12/ft-Icon-dark.png" rel="shortcut icon" /> 




		<link rel="preconnect" href="https://fonts.googleapis.com" crossorigin/>
	
	<script type="text/javascript">
	    var tf_mobile_menu_trigger_point = 900;
	</script>
	
<meta name="viewport" content="width=device-width, initial-scale=1">

	<style>
	@-webkit-keyframes themifyAnimatedBG {
		0% { background-color: #33baab; }
100% { background-color: #e33b9e; }
50% { background-color: #4961d7; }
33.333333333333% { background-color: #2ea85c; }
25% { background-color: #2bb8ed; }
20% { background-color: #dd5135; }

	}
	@keyframes themifyAnimatedBG {
		0% { background-color: #33baab; }
100% { background-color: #e33b9e; }
50% { background-color: #4961d7; }
33.333333333333% { background-color: #2ea85c; }
25% { background-color: #2bb8ed; }
20% { background-color: #dd5135; }

	}
	.themify_builder_row.animated-bg {
		-webkit-animation: themifyAnimatedBG 30000ms infinite alternate;
		animation: themifyAnimatedBG 30000ms infinite alternate;
	}
	</style>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
</head>

<body class="home page-template-default page page-id-27 themify-fw-4-8-1 themify-ultra-2-1-4 skin-default not-ie full_width sidebar-none no-touch builder-parallax-scrolling-active ready-view header-horizontal fixed-header transparent-header footer-none theme-color-black  rss-off search-off footer-off tile_enable filter-hover-none filter-featured-only masonry-enabled">

<script type="text/javascript">
	function themifyMobileMenuTrigger(e) {
		var w = document.body.clientWidth;
		if( w > 0 && w <= tf_mobile_menu_trigger_point ) {
			document.body.classList.add( 'mobile_menu_active' );
		} else {
			document.body.classList.remove( 'mobile_menu_active' );
		}
		
	}
	themifyMobileMenuTrigger();
	var _init =function () {
	    jQuery( window ).on('tfsmartresize.tf_mobile_menu', themifyMobileMenuTrigger );
	    document.removeEventListener( 'DOMContentLoaded', _init, {once:true,passive:true} );
	    _init=null;
	};
	document.addEventListener( 'DOMContentLoaded', _init, {once:true,passive:true} );
</script>

<div id="pagewrap" class="hfeed site">

			<div id="headerwrap"   >
                        			                                                    <div class="header-icons">
                                <a id="menu-icon" href="#mobile-menu"><span class="menu-icon-inner"></span></a>
                            </div>
                        
			<header id="header" class="pagewidth clearfix" itemscope="itemscope" itemtype="https://schema.org/WPHeader">

	            
	            <div class="header-bar">
		            						<div id="site-logo"><a href="http://www.forwardthinkingscience.co.uk" title="Forward Thinking"><img src="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2018/12/ft-Icon-light-Tran-2.png" alt="Forward Thinking" title="ft Icon (light) Tran 2" /></a></div>					
											<div id="site-description" class="site-description"><span>Helping Students Re-Engage With Science</span></div>									</div>
				<!-- /.header-bar -->

									<div id="mobile-menu" class="sidemenu sidemenu-off">

						<div class="navbar-wrapper clearfix">

															<div class="social-widget">
																			<div id="themify-social-links-2" class="widget themify-social-links"><ul class="social-links horizontal">
							<li class="social-link-item facebook font-icon icon-medium">
								<a href="https://www.facebook.com/forwardthinkingscience/" target="_blank"><i class="fa fa-facebook" ></i>  </a>
							</li>
							<!-- /themify-link-item -->
							<li class="social-link-item instagram font-icon icon-medium">
								<a href="https://www.instagram.com/forwardthinkingscience/" target="_blank"><i class="fa fa-instagram" ></i>  </a>
							</li>
							<!-- /themify-link-item -->
							<li class="social-link-item youtube font-icon icon-medium">
								<a href="https://www.youtube.com/channel/UCV3QZR2lOUdXeZvXCwQAQ4w" target="_blank"><i class="fa fa-youtube-play" ></i>  </a>
							</li>
							<!-- /themify-link-item --></ul></div>									
																	</div>
								<!-- /.social-widget -->
							
							
							<nav id="main-nav-wrap" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
																	<ul id="main-nav" class="main-nav menu-name-nav-bar"><li id='menu-item-85' class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-has-children has-sub-menu has-sub-menu" ><a  href="http://www.forwardthinkingscience.co.uk/#aboutus">About Us</a> 
<ul class="sub-menu">
<li id='menu-item-285' class="menu-item menu-item-type-post_type menu-item-object-page" ><a  href="http://www.forwardthinkingscience.co.uk/our-story-ethos/">Our Story &#038; Ethos</a> </li>
</ul>
</li>
<li id='menu-item-86' class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-has-children has-sub-menu has-sub-menu" ><a  href="http://www.forwardthinkingscience.co.uk/#services">Services</a> 
<ul class="sub-menu">
<li id='menu-item-310' class="menu-item menu-item-type-post_type menu-item-object-page" ><a  href="http://www.forwardthinkingscience.co.uk/all-subjects/biology/">Biology</a> </li>
<li id='menu-item-309' class="menu-item menu-item-type-post_type menu-item-object-page" ><a  href="http://www.forwardthinkingscience.co.uk/all-subjects/chemistry/">Chemistry</a> </li>
<li id='menu-item-311' class="menu-item menu-item-type-post_type menu-item-object-page" ><a  href="http://www.forwardthinkingscience.co.uk/all-subjects/physics/">Physics</a> </li>
</ul>
</li>
<li id='menu-item-89' class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home" ><a  href="http://www.forwardthinkingscience.co.uk/#Media">Media</a> </li>
<li id='menu-item-265' class="menu-item menu-item-type-post_type menu-item-object-page" ><a  href="http://www.forwardthinkingscience.co.uk/blog/">Blog</a> </li>
<li id='menu-item-87' class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home" ><a  href="http://www.forwardthinkingscience.co.uk/#testimonials">Testimonials</a> </li>
<li id='menu-item-88' class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home" ><a  href="http://www.forwardthinkingscience.co.uk/#Contactus">Contact Us</a> </li>
</ul>									<!-- /#main-nav -->
									
																		
															</nav>
							<!-- /#main-nav-wrap -->
							
						</div>

																				<!-- /header-widgets -->
						
						<a id="menu-icon-close" href="#"></a>
					</div>
					<!-- /#mobile-menu -->
				
				
				
				
			</header>
			<!-- /#header -->

	        
		</div>
		<!-- /#headerwrap -->
	
	<div id="body" class="clearfix">

		

<!-- layout-container -->
<div id="layout" class="pagewidth clearfix">

		<!-- content -->
	<div id="content" class="clearfix">
    	
		
							<div id="page-27" class="type-page">

			<!-- page-title -->
						<!-- /page-title -->

			<div class="page-content entry-content">

				
				<link rel="preload" href="http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/themify/themify-builder/css/themify-builder-style.min.css?ver=4.8.1" as="style" /><script type="text/javascript">
				if(document.getElementById( "themify-builder-style" )===null ){
					var el =  document.getElementById( "builder-styles-css" );
					if(el!==null){
					var link = document.createElement("link");
					link.id="themify-builder-style";
					link.rel="stylesheet";
					link.type="text/css";
					link.href=el.getAttribute("data-href");
					el.parentNode.replaceChild( link, el);
					}
				}
			</script><div id="themify_builder_content-27" data-postid="27" class="themify_builder_content themify_builder_content-27 themify_builder">
    	<!-- module_row -->
	<div  data-fullwidthvideo="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2018/12/Northern-Lights-2267.mp4" data-playonmobile="play" class="themify_builder_row module_row clearfix repeat fullheight fullwidth module_row_0 themify_builder_27_row module_row_27-0 tb_88c76cd">
	    <div class="builder_row_cover"></div>						<div class="tb_row_frame tb_row_frame_bottom "></div>
							    <div class="row_inner col_align_top" >
			<div  class="module_column tb-column col-full first tb_27_column module_column_0 module_column_27-0-0 tb_b62540f">
	    	    	        <div class="tb-column-inner">
		    	<div  class="themify_builder_sub_row module_subrow clearfix sub_row_0-0-0 tb_4c04f36">
	    	    <div class="subrow_inner col_align_top"   data-basecol="3" data-col_tablet="column-full">
			<div  class="sub_column module_column col3-1 first sub_column_post_27 sub_column_0-0-0-0 tb_35d7c1e"> 
	    	    	</div>
		<div  class="sub_column module_column col3-1 middle sub_column_post_27 sub_column_0-0-0-1 tb_96a29b8" > 
	    	    	        <div class="tb-column-inner">
		        <!-- module image -->
    <div  class="module module-image tb_b58a1ab  image-top   wow fadeIn animation_effect_delay_1  auto_fullwidth">
	                <div class="image-wrap">
                            <img src="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/01/ft-Scotland-light-tran-7-1024x634-500x309.png" width="500" class=" wp-post-image wp-image-208" alt="ft Scotland (light) tran 7" srcset="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/01/ft-Scotland-light-tran-7-1024x634-500x309.png 500w, http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/01/ft-Scotland-light-tran-7-300x186.png 300w, http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/01/ft-Scotland-light-tran-7-768x476.png 768w, http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/01/ft-Scotland-light-tran-7-1024x634.png 1024w, http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/01/ft-Scotland-light-tran-7.png 2001w" sizes="(max-width: 500px) 100vw, 500px" />            
                        </div>
            <!-- /image-wrap -->
        
        
        </div>
    <!-- /module image -->
    <!-- module buttons -->
    <div  class="module module-buttons tb_19aadae small outline circle   wow fadeIn animation_effect_delay_1.5">
	        	<div class="module-buttons">
                            <div class="module-buttons-item  buttons-vertical">
		    			<a href="#services" class="ui builder_button tb_default_color" >
		    		    			<span>Our Services</span>
		    		    			</a>
		                    </div>
                    </div>
    </div>
    <!-- /module buttons -->
	        </div>
	    	</div>
		<div  class="sub_column module_column col3-1 last sub_column_post_27 sub_column_0-0-0-2 tb_8a97da8"> 
	    	    	</div>
		    </div>
	</div><!-- /themify_builder_sub_row -->
		        </div>
	    	</div>
		    </div>
	    <!-- /row_inner -->
	</div>
	<!-- /module_row -->
		<!-- module_row -->
	<div   class="themify_builder_row module_row clearfix repeat module_row_1 themify_builder_27_row module_row_27-1 tb_5f1f395">
	    	    <div class="row_inner col_align_top" >
			<div  class="module_column tb-column col-full first tb_27_column module_column_0 module_column_27-1-0 tb_96e7373">
	    	    	        <div class="tb-column-inner">
		    <!-- module text -->
<div  class="module module-text tb_8238ab1  repeat  ">
            <div  class="tb_text_wrap">
    <p style="text-align: center;"><em>&#8220;It is the supreme art of the teacher to awaken joy in creative expression and knowledge.&#8221; </em></p>
<h6 style="text-align: center;"><strong>Albert Einstein</strong></h6>
<p style="text-align: center;"> </p>    </div>
</div>
<!-- /module text -->
	        </div>
	    	</div>
		    </div>
	    <!-- /row_inner -->
	</div>
	<!-- /module_row -->
		<!-- module_row -->
	<div   data-anchor="aboutus" class="themify_builder_row module_row clearfix repeat tb_section-aboutus module_row_3 themify_builder_27_row module_row_27-3 tb_77dbaa4">
	    	    <div class="row_inner col_align_middle"   data-mobile_dir="rtl" data-basecol="2" data-col_mobile="column-full">
			<div  class="module_column tb-column col4-3 first tb_27_column module_column_0 module_column_27-3-0 tb_d34345b" style="width: 56.8%">
	    	    	        <div class="tb-column-inner">
		    <!-- module text -->
<div  class="module module-text tb_fc8a9d3  repeat  ">
            <div  class="tb_text_wrap">
    <h2>About Us</h2>    </div>
</div>
<!-- /module text -->
<!-- module text -->
<div  class="module module-text tb_5199a2f  repeat  ">
            <div  class="tb_text_wrap">
    <p>Forward Thinking (FT) is the first dedicated science tuition centre in Scotland. The goal of FT is to help students develop a critical mindset and re-engage with the sciences. We provide tuition in <strong>Biology, Chemistry and Physics at national 5 and higher level</strong>.</p>
<p>Our tutors are all highly competent within their fields and have excellent communication skills. This combination of traits ensures that the true potential of each child is brought out fully at FT.</p>    </div>
</div>
<!-- /module text -->
	<div  class="themify_builder_sub_row module_subrow clearfix repeat sub_row_3-0-2 tb_e41d0e4" >
	    	    <div class="subrow_inner col_align_top" >
			<div  class="sub_column module_column col2-1 first sub_column_post_27 sub_column_3-0-2-0 tb_883e293 repeat" > 
	    	    	        <div class="tb-column-inner">
		        <!-- module buttons -->
    <div  class="module module-buttons tb_4e9b2c2 small outline circle   wow fadeInLeft">
	        	<div class="module-buttons">
                            <div class="module-buttons-item  buttons-horizontal">
		    			<a href="http://www.forwardthinkingscience.co.uk/our-story-ethos/" class="ui builder_button green" >
		    		    			<span>Our Story & Ethos</span>
		    		    			</a>
		                    </div>
                    </div>
    </div>
    <!-- /module buttons -->
    <!-- module buttons -->
    <div  class="module module-buttons tb_54ap012 small outline circle   wow fadeInLeft animation_effect_delay_0.4">
	        	<div class="module-buttons">
                            <div class="module-buttons-item  buttons-horizontal">
		    			<a href="#testimonials" class="ui builder_button green" >
		    		    			<span>Testimonials</span>
		    		    			</a>
		                    </div>
                    </div>
    </div>
    <!-- /module buttons -->
	        </div>
	    	</div>
		<div  class="sub_column module_column col2-1 last sub_column_post_27 sub_column_3-0-2-1 tb_dee1c63"> 
	    	    	</div>
		    </div>
	</div><!-- /themify_builder_sub_row -->
		        </div>
	    	</div>
		<div  class="module_column tb-column col4-1 last tb_27_column module_column_1 module_column_27-3-1 tb_45859c9" style="width: 40%" >
	    	    	        <div class="tb-column-inner">
		        <!-- module image -->
    <div  class="module module-image tb_04547d7  image-top  ">
	                <div class="image-wrap">
                            <img loading="lazy" width="1000" height="1187" src="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/03/3e.jpg" class=" wp-post-image wp-image-228" alt="3e" srcset="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/03/3e.jpg 1000w, http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/03/3e-253x300.jpg 253w, http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/03/3e-768x912.jpg 768w, http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/03/3e-863x1024.jpg 863w, http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/03/3e-863x1024-421x500.jpg 421w" sizes="(max-width: 1000px) 100vw, 1000px" />            
                        </div>
            <!-- /image-wrap -->
        
        
        </div>
    <!-- /module image -->
	        </div>
	    	</div>
		    </div>
	    <!-- /row_inner -->
	</div>
	<!-- /module_row -->
		<!-- module_row -->
	<div   data-anchor="services" class="themify_builder_row module_row clearfix repeat fullwidth tb_section-services module_row_4 themify_builder_27_row module_row_27-4 tb_26625c5">
	    	    <div class="row_inner col_align_middle gutter-none"   data-basecol="2" data-col_tablet="column-full">
			<div  class="module_column tb-column col4-2 first tb_27_column module_column_0 module_column_27-4-0 tb_c91c830 fullcover" >
	    <div class="builder_row_cover"></div>	    	        <div class="tb-column-inner">
		    <!-- module text -->
<div  class="module module-text tb_8a3f019  repeat  ">
            <div  class="tb_text_wrap">
    <h2>Our Services</h2>    </div>
</div>
<!-- /module text -->
<!-- module text -->
<div  class="module module-text tb_96qm044  repeat   hide-desktop">
            <div  class="tb_text_wrap">
    <h4><strong><a href="http://www.forwardthinkingscience.co.uk/all-subjects/biology/">BIOLOGY </a> |  <a href="http://www.forwardthinkingscience.co.uk/all-subjects/chemistry/">CHEMISTRY </a></strong><strong> <br /><a href="http://www.forwardthinkingscience.co.uk/all-subjects/physics/">PHYSICS</a></strong></h4>    </div>
</div>
<!-- /module text -->
<!-- module text -->
<div  class="module module-text tb_o5ix203  repeat   hide-tablet hide-mobile">
            <div  class="tb_text_wrap">
    <h4><strong><a href="http://www.forwardthinkingscience.co.uk/all-subjects/biology/">BIOLOGY </a> |  <a href="http://www.forwardthinkingscience.co.uk/all-subjects/chemistry/">CHEMISTRY </a></strong><strong> | </strong><strong><a href="http://www.forwardthinkingscience.co.uk/all-subjects/physics/">PHYSICS</a></strong></h4>    </div>
</div>
<!-- /module text -->
    <!-- module divider -->
    <div  class="module module-divider tb_43ce4e7 solid   divider-custom divider-center" style="border-width: 2px;border-color: #ffffff;margin-top: 10px;margin-bottom: 40px;width: 150px;">
	            </div>
    <!-- /module divider -->
<!-- module text -->
<div  class="module module-text tb_df569ce  repeat  ">
            <div  class="tb_text_wrap">
    <h4>What you will get</h4>
<p>To achieve mastery of the sciences. Students attend a 1 hour class per week which is composed of a lecture on a specific subtopic and questions to develop a practical understanding of the subject. Tailor-made homework is given to each student every week to target individual weaknesses.</p>    </div>
</div>
<!-- /module text -->
    <!-- module buttons -->
    <div  class="module module-buttons tb_f42419e small outline circle   wow fadeInDown">
	        	<div class="module-buttons">
                            <div class="module-buttons-item  buttons-horizontal">
		    			<a href="http://www.forwardthinkingscience.co.uk/all-subjects/" class="ui builder_button tb_default_color" >
		    		    			<span>All Subjects</span>
		    		    			</a>
		                    </div>
                    </div>
    </div>
    <!-- /module buttons -->
    <!-- module buttons -->
    <div  class="module module-buttons tb_61hk004 small outline circle   wow fadeInDown animation_effect_delay_0.4">
	        	<div class="module-buttons">
                            <div class="module-buttons-item  buttons-horizontal">
		    			<a href="#testimonials" class="ui builder_button tb_default_color" >
		    		    			<span>Testimonials</span>
		    		    			</a>
		                    </div>
                    </div>
    </div>
    <!-- /module buttons -->
	        </div>
	    	</div>
		<div  class="module_column tb-column col4-2 last tb_27_column module_column_1 module_column_27-4-1 tb_df5bb3d repeat" >
	    	    	        <div class="tb-column-inner">
		        <!-- module feature -->
   <div  class="module module-feature tb_4a0ffe1 with-chart layout-icon-left size-small  ">
        <style type="text/css">.tb_4a0ffe1 .module-feature-chart-html5 {
			    box-shadow: inset 0 0 0 3px rgba(0,0,0,.1);
			}
			.tb_4a0ffe1 .chart-loaded.chart-html5-fill {
			    box-shadow: inset 0 0 0 3px #68f06e;
		    }</style>
        
        <div class="module-feature-image">
            
            
                <div class="module-feature-chart-html5"
                                         data-progress="0"
                         data-progress-end="100"
                         data-size="100"
                                          >
                    <div class="chart-html5-circle">
                                                    <div class="chart-html5-mask chart-html5-full">
                                <div class="chart-html5-fill"></div>
                            </div>
                            <div class="chart-html5-mask chart-html5-half">
                                <div class="chart-html5-fill"></div>
                            </div>
                                                <div class="chart-html5-inset chart-html5-inset-icon">

                                                                                            <i class="module-feature-icon fa fa-users" style="color: #68f06e"></i>                            
                        </div>
                    </div>
                </div>

                        </div>

        <div class="module-feature-content">
			                                        <h3 class="module-feature-title">
                                                                                            Small Class Size                                                                                    </h3>
                                	    <div class="tb_text_wrap">
		<p>Four students maximum per teacher, to ensure each student receives enough guidance and also help develop independent study skills.</p>	    </div>
	</div>

    </div>
    <!-- /module feature -->
    <!-- module feature -->
   <div  class="module module-feature tb_84163b3 with-chart layout-icon-left size-small  ">
        <style type="text/css">.tb_84163b3 .module-feature-chart-html5 {
			    box-shadow: inset 0 0 0 3px rgba(0,0,0,.1);
			}
			.tb_84163b3 .chart-loaded.chart-html5-fill {
			    box-shadow: inset 0 0 0 3px #68f06e;
		    }</style>
        
        <div class="module-feature-image">
            
            
                <div class="module-feature-chart-html5"
                                         data-progress="0"
                         data-progress-end="100"
                         data-size="100"
                                          >
                    <div class="chart-html5-circle">
                                                    <div class="chart-html5-mask chart-html5-full">
                                <div class="chart-html5-fill"></div>
                            </div>
                            <div class="chart-html5-mask chart-html5-half">
                                <div class="chart-html5-fill"></div>
                            </div>
                                                <div class="chart-html5-inset chart-html5-inset-icon">

                                                                                            <i class="module-feature-icon fa fa-check-square-o" style="color: #68f06e"></i>                            
                        </div>
                    </div>
                </div>

                        </div>

        <div class="module-feature-content">
			                                        <h3 class="module-feature-title">
                                                                                            Regular feedback                                                                                    </h3>
                                	    <div class="tb_text_wrap">
		<p>This allows parents and students to easily track progress and identify areas of weakness. Helping students learn how to utilise and structure their time effectively.</p>	    </div>
	</div>

    </div>
    <!-- /module feature -->
    <!-- module feature -->
   <div  class="module module-feature tb_49945d3 with-chart layout-icon-left size-small  ">
        <style type="text/css">.tb_49945d3 .module-feature-chart-html5 {
			    box-shadow: inset 0 0 0 3px rgba(0,0,0,.1);
			}
			.tb_49945d3 .chart-loaded.chart-html5-fill {
			    box-shadow: inset 0 0 0 3px #68f06e;
		    }</style>
        
        <div class="module-feature-image">
            
            
                <div class="module-feature-chart-html5"
                                         data-progress="0"
                         data-progress-end="100"
                         data-size="100"
                                          >
                    <div class="chart-html5-circle">
                                                    <div class="chart-html5-mask chart-html5-full">
                                <div class="chart-html5-fill"></div>
                            </div>
                            <div class="chart-html5-mask chart-html5-half">
                                <div class="chart-html5-fill"></div>
                            </div>
                                                <div class="chart-html5-inset chart-html5-inset-icon">

                                                                                            <i class="module-feature-icon fa fa-puzzle-piece" style="color: #68f06e"></i>                            
                        </div>
                    </div>
                </div>

                        </div>

        <div class="module-feature-content">
			                                        <h3 class="module-feature-title">
                                                                                            Bespoke Learning Curriculum                                                                                    </h3>
                                	    <div class="tb_text_wrap">
		<p>Limiting the sizes of our class allows us to create bespoke material appropriate to the needs and levels of each individual student.</p>	    </div>
	</div>

    </div>
    <!-- /module feature -->
    <!-- module feature -->
   <div  class="module module-feature tb_jcvf077 with-chart layout-icon-left size-small  ">
        <style type="text/css">.tb_jcvf077 .module-feature-chart-html5 {
			    box-shadow: inset 0 0 0 3px rgba(0,0,0,.1);
			}
			.tb_jcvf077 .chart-loaded.chart-html5-fill {
			    box-shadow: inset 0 0 0 3px #68f06e;
		    }</style>
        
        <div class="module-feature-image">
            
            
                <div class="module-feature-chart-html5"
                                         data-progress="0"
                         data-progress-end="100"
                         data-size="100"
                                          >
                    <div class="chart-html5-circle">
                                                    <div class="chart-html5-mask chart-html5-full">
                                <div class="chart-html5-fill"></div>
                            </div>
                            <div class="chart-html5-mask chart-html5-half">
                                <div class="chart-html5-fill"></div>
                            </div>
                                                <div class="chart-html5-inset chart-html5-inset-icon">

                                                                                            <i class="module-feature-icon fa fa-connectdevelop" style="color: #68f06e"></i>                            
                        </div>
                    </div>
                </div>

                        </div>

        <div class="module-feature-content">
			                                        <h3 class="module-feature-title">
                                                                                            Mastery                                                                                    </h3>
                                	    <div class="tb_text_wrap">
		<p>The cyclic structure of our programme helps students develop a solid understanding of each topic. Each time a topic is revisited, students either consolidate or develop their understanding.</p>	    </div>
	</div>

    </div>
    <!-- /module feature -->
	        </div>
	    	</div>
		    </div>
	    <!-- /row_inner -->
	</div>
	<!-- /module_row -->
		<!-- module_row -->
	<div   data-anchor="Media" class="themify_builder_row module_row clearfix fullcover tb_section-Media module_row_5 themify_builder_27_row module_row_27-5 tb_00a60ec">
	    	    <div class="row_inner col_align_top" >
			<div  class="module_column tb-column col-full first tb_27_column module_column_0 module_column_27-5-0 tb_7458b25">
	    	    	        <div class="tb-column-inner">
		    <!-- module text -->
<div  class="module module-text tb_87bf289  repeat  ">
            <div  class="tb_text_wrap">
    <h2>Media</h2>    </div>
</div>
<!-- /module text -->

    <!-- module video -->
    <div  class="module module-video tb_0daa1ba video-top   ">
	                <div class="video-wrap">
	    <iframe title="Intermolecular forces" width="1165" height="655" src="https://www.youtube.com/embed/Tyj2OIuEi5o?feature=oembed"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>        </div>
        <!-- /video-wrap -->

            </div>
    <!-- /module video -->
    <!-- module text -->
<div  class="module module-text tb_20475b5  repeat  ">
            <div  class="tb_text_wrap">
    
<div id="sb_instagram" class="sbi sbi_col_3  sbi_width_resp sbi_disable_mobile" style="padding-bottom: 10px;width: 100%;" data-feedid="sbi_forwardthinkingscience#3" data-res="auto" data-cols="3" data-num="3" data-shortcode-atts="{}" >
	
    <div id="sbi_images" style="padding: 5px;">
		<div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17850670496075131" data-date="1589725964">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/CASt4fah0dx/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent-lhr8-1.cdninstagram.com/v/t51.2885-15/97219610_583102039254491_7200441765627156181_n.jpg?_nc_cat=111&#038;ccb=2&#038;_nc_sid=8ae9d6&#038;_nc_ohc=ZrpUeUfZPzUAX9I3TTH&#038;_nc_ht=scontent-lhr8-1.cdninstagram.com&#038;oh=474b238d175380f3e606e3e13c58e68b&#038;oe=600E9DED" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent-lhr8-1.cdninstagram.com\/v\/t51.2885-15\/97219610_583102039254491_7200441765627156181_n.jpg?_nc_cat=111&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=ZrpUeUfZPzUAX9I3TTH&amp;_nc_ht=scontent-lhr8-1.cdninstagram.com&amp;oh=474b238d175380f3e606e3e13c58e68b&amp;oe=600E9DED&quot;,&quot;150&quot;:&quot;https:\/\/scontent-lhr8-1.cdninstagram.com\/v\/t51.2885-15\/97219610_583102039254491_7200441765627156181_n.jpg?_nc_cat=111&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=ZrpUeUfZPzUAX9I3TTH&amp;_nc_ht=scontent-lhr8-1.cdninstagram.com&amp;oh=474b238d175380f3e606e3e13c58e68b&amp;oe=600E9DED&quot;,&quot;320&quot;:&quot;https:\/\/scontent-lhr8-1.cdninstagram.com\/v\/t51.2885-15\/97219610_583102039254491_7200441765627156181_n.jpg?_nc_cat=111&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=ZrpUeUfZPzUAX9I3TTH&amp;_nc_ht=scontent-lhr8-1.cdninstagram.com&amp;oh=474b238d175380f3e606e3e13c58e68b&amp;oe=600E9DED&quot;,&quot;640&quot;:&quot;https:\/\/scontent-lhr8-1.cdninstagram.com\/v\/t51.2885-15\/97219610_583102039254491_7200441765627156181_n.jpg?_nc_cat=111&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=ZrpUeUfZPzUAX9I3TTH&amp;_nc_ht=scontent-lhr8-1.cdninstagram.com&amp;oh=474b238d175380f3e606e3e13c58e68b&amp;oe=600E9DED&quot;}">
            <span class="sbi-screenreader">We’re proud to say we’ve run over 150 online c</span>
            	                    <img src="http://www.forwardthinkingscience.co.uk/wp-content/plugins/instagram-feed/img/placeholder.png" alt="We’re proud to say we’ve run over 150 online classes held since lockdown began! 🥳🥳 Our students and tutors have been solidly working away throughout this time and are all well on their way to success! 🤸🏻 Well done...forward thinkers!">
        </a>
    </div>
</div><div class="sbi_item sbi_type_carousel sbi_new sbi_transition" id="sbi_18053396320230916" data-date="1587981539">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/B_euqAQg11F/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent-lht6-1.cdninstagram.com/v/t51.2885-15/95056050_546801549591544_1154222465410993413_n.jpg?_nc_cat=106&#038;ccb=2&#038;_nc_sid=8ae9d6&#038;_nc_ohc=3gN6nfzwvQcAX8Me2Fj&#038;_nc_oc=AQmkHRNUh5Kju73N4KUrLjCfzoxjuqTPXsiDDs8HykXrZlJVRueAeuEG9DNzO1oxQrw&#038;_nc_ht=scontent-lht6-1.cdninstagram.com&#038;oh=269c06e9bbafa99d2cbed8e63067be04&#038;oe=600DD18C" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent-lht6-1.cdninstagram.com\/v\/t51.2885-15\/95056050_546801549591544_1154222465410993413_n.jpg?_nc_cat=106&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=3gN6nfzwvQcAX8Me2Fj&amp;_nc_oc=AQmkHRNUh5Kju73N4KUrLjCfzoxjuqTPXsiDDs8HykXrZlJVRueAeuEG9DNzO1oxQrw&amp;_nc_ht=scontent-lht6-1.cdninstagram.com&amp;oh=269c06e9bbafa99d2cbed8e63067be04&amp;oe=600DD18C&quot;,&quot;150&quot;:&quot;https:\/\/scontent-lht6-1.cdninstagram.com\/v\/t51.2885-15\/95056050_546801549591544_1154222465410993413_n.jpg?_nc_cat=106&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=3gN6nfzwvQcAX8Me2Fj&amp;_nc_oc=AQmkHRNUh5Kju73N4KUrLjCfzoxjuqTPXsiDDs8HykXrZlJVRueAeuEG9DNzO1oxQrw&amp;_nc_ht=scontent-lht6-1.cdninstagram.com&amp;oh=269c06e9bbafa99d2cbed8e63067be04&amp;oe=600DD18C&quot;,&quot;320&quot;:&quot;https:\/\/scontent-lht6-1.cdninstagram.com\/v\/t51.2885-15\/95056050_546801549591544_1154222465410993413_n.jpg?_nc_cat=106&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=3gN6nfzwvQcAX8Me2Fj&amp;_nc_oc=AQmkHRNUh5Kju73N4KUrLjCfzoxjuqTPXsiDDs8HykXrZlJVRueAeuEG9DNzO1oxQrw&amp;_nc_ht=scontent-lht6-1.cdninstagram.com&amp;oh=269c06e9bbafa99d2cbed8e63067be04&amp;oe=600DD18C&quot;,&quot;640&quot;:&quot;https:\/\/scontent-lht6-1.cdninstagram.com\/v\/t51.2885-15\/95056050_546801549591544_1154222465410993413_n.jpg?_nc_cat=106&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=3gN6nfzwvQcAX8Me2Fj&amp;_nc_oc=AQmkHRNUh5Kju73N4KUrLjCfzoxjuqTPXsiDDs8HykXrZlJVRueAeuEG9DNzO1oxQrw&amp;_nc_ht=scontent-lht6-1.cdninstagram.com&amp;oh=269c06e9bbafa99d2cbed8e63067be04&amp;oe=600DD18C&quot;}">
            <span class="sbi-screenreader">Higher maths made easy! 
Haaaashtags 🤾🏻 #for</span>
            <svg class="svg-inline--fa fa-clone fa-w-16 sbi_lightbox_carousel_icon" aria-hidden="true" aria-label="Clone" data-fa-proƒcessed="" data-prefix="far" data-icon="clone" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
	                <path fill="currentColor" d="M464 0H144c-26.51 0-48 21.49-48 48v48H48c-26.51 0-48 21.49-48 48v320c0 26.51 21.49 48 48 48h320c26.51 0 48-21.49 48-48v-48h48c26.51 0 48-21.49 48-48V48c0-26.51-21.49-48-48-48zM362 464H54a6 6 0 0 1-6-6V150a6 6 0 0 1 6-6h42v224c0 26.51 21.49 48 48 48h224v42a6 6 0 0 1-6 6zm96-96H150a6 6 0 0 1-6-6V54a6 6 0 0 1 6-6h308a6 6 0 0 1 6 6v308a6 6 0 0 1-6 6z"></path>
	            </svg>	                    <img src="http://www.forwardthinkingscience.co.uk/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Higher maths made easy! 
Haaaashtags 🤾🏻 #forwardthinkingscience #forwardthinking #forwardthinkingtuition #ftmaths #highermaths #parallellines #instamath #instamaths #straightline #green #triangles #educationscotland #educationiskey #mathtutorial #mathtutorials #ipadonly #dailymath #mathematics #tutorial #makeuptutorial">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17870741584687310" data-date="1587822526">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/B_Z_XNTANSa/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent-lhr8-1.cdninstagram.com/v/t51.2885-15/95139840_157264659048277_7349619449213877053_n.jpg?_nc_cat=110&#038;ccb=2&#038;_nc_sid=8ae9d6&#038;_nc_ohc=hXhlTf__ofUAX_uc-lX&#038;_nc_ht=scontent-lhr8-1.cdninstagram.com&#038;oh=c17c40262fc30fb1aa6f89ec4a4974a7&#038;oe=60100D43" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent-lhr8-1.cdninstagram.com\/v\/t51.2885-15\/95139840_157264659048277_7349619449213877053_n.jpg?_nc_cat=110&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=hXhlTf__ofUAX_uc-lX&amp;_nc_ht=scontent-lhr8-1.cdninstagram.com&amp;oh=c17c40262fc30fb1aa6f89ec4a4974a7&amp;oe=60100D43&quot;,&quot;150&quot;:&quot;https:\/\/scontent-lhr8-1.cdninstagram.com\/v\/t51.2885-15\/95139840_157264659048277_7349619449213877053_n.jpg?_nc_cat=110&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=hXhlTf__ofUAX_uc-lX&amp;_nc_ht=scontent-lhr8-1.cdninstagram.com&amp;oh=c17c40262fc30fb1aa6f89ec4a4974a7&amp;oe=60100D43&quot;,&quot;320&quot;:&quot;https:\/\/scontent-lhr8-1.cdninstagram.com\/v\/t51.2885-15\/95139840_157264659048277_7349619449213877053_n.jpg?_nc_cat=110&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=hXhlTf__ofUAX_uc-lX&amp;_nc_ht=scontent-lhr8-1.cdninstagram.com&amp;oh=c17c40262fc30fb1aa6f89ec4a4974a7&amp;oe=60100D43&quot;,&quot;640&quot;:&quot;https:\/\/scontent-lhr8-1.cdninstagram.com\/v\/t51.2885-15\/95139840_157264659048277_7349619449213877053_n.jpg?_nc_cat=110&amp;ccb=2&amp;_nc_sid=8ae9d6&amp;_nc_ohc=hXhlTf__ofUAX_uc-lX&amp;_nc_ht=scontent-lhr8-1.cdninstagram.com&amp;oh=c17c40262fc30fb1aa6f89ec4a4974a7&amp;oe=60100D43&quot;}">
            <span class="sbi-screenreader"></span>
            	                    <img src="http://www.forwardthinkingscience.co.uk/wp-content/plugins/instagram-feed/img/placeholder.png" alt="A very wise ant. 
Work hard! 🏋🏻
Take breaks🧘🏻
Juggle 🤹🏻 Don’t inject disinfectant to cure the corona virus...
#donaldtrump 
#dailyinspo">
        </a>
    </div>
</div>    </div>

	<div id="sbi_load">

	
	
</div>
	    <span class="sbi_resized_image_data" data-feed-id="sbi_forwardthinkingscience#3" data-resized="{&quot;17870741584687310&quot;:{&quot;id&quot;:&quot;95139840_157264659048277_7349619449213877053_n&quot;,&quot;ratio&quot;:&quot;1.01&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;18053396320230916&quot;:{&quot;id&quot;:&quot;95056050_546801549591544_1154222465410993413_n&quot;,&quot;ratio&quot;:&quot;1.00&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17850670496075131&quot;:{&quot;id&quot;:&quot;97219610_583102039254491_7200441765627156181_n&quot;,&quot;ratio&quot;:&quot;1.00&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}}}">
	</span>
	</div>

    </div>
</div>
<!-- /module text -->
    <!-- module post -->
    <div  class="module module-post tb_1956626 ">
                <div class="builder-posts-wrap clearfix loops-wrapper  grid3 boxed">
            

<article id="post-260" class="post clearfix post-260 type-post status-publish format-standard has-post-thumbnail hentry category-biology has-post-title has-post-date has-post-category has-post-tag has-post-comment has-post-author   cat-6">
	
            <a href="http://www.forwardthinkingscience.co.uk/5-biology-study-tips/" data-post-permalink="yes" style="display: none;"></a>
    
	
	
	
		
			<figure class="post-image  clearfix">

									<a href="http://www.forwardthinkingscience.co.uk/5-biology-study-tips/"><img loading="lazy" src="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/07/dna-3539309_1280-1024x512-400x300.jpg" width="400" height="300" class=" wp-post-image wp-image-262" alt="dna-3539309_1280" /></a>
				
			</figure>

		
	
	
	<div class="post-content">
		<div class="post-content-inner">

							<div class="post-date-wrap">
					<time class="post-date entry-date updated" datetime="2019-07-22">
                                                                                                                                                                                                <span class="month">July</span>
                                                                                                    <span class="day">22</span>
                                                                                                    <span class="year">2019</span>
                                                                                            					</time>
				</div>
			
							 <h2 class="post-title entry-title"><a href="http://www.forwardthinkingscience.co.uk/5-biology-study-tips/">5 Biology Study Tips</a> </h2>			
							<p class="post-meta entry-meta">
											<span class="post-author"><span class="author vcard"><a class="url fn n" href="http://www.forwardthinkingscience.co.uk/author/admin/" rel="author">admin</a></span></span>
					
											 <span class="post-category"><a href="http://www.forwardthinkingscience.co.uk/category/biology/" rel="tag" class="term-biology">Biology</a></span>					
																
									</p>
				<!-- /post-meta -->
			
			
			<div class="entry-content">

				
				
			</div><!-- /.entry-content -->

			
		</div>
		<!-- /.post-content-inner -->
	</div>
	<!-- /.post-content -->
	
</article>
<!-- /.post -->


<article id="post-257" class="post clearfix post-257 type-post status-publish format-standard has-post-thumbnail hentry category-chemistry has-post-title has-post-date has-post-category has-post-tag has-post-comment has-post-author   cat-5">
	
            <a href="http://www.forwardthinkingscience.co.uk/5-chemistry-study-tips/" data-post-permalink="yes" style="display: none;"></a>
    
	
	
	
		
			<figure class="post-image  clearfix">

									<a href="http://www.forwardthinkingscience.co.uk/5-chemistry-study-tips/"><img loading="lazy" src="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/07/analysis-2030265_1280-1024x682-400x300.jpg" width="400" height="300" class=" wp-post-image wp-image-259" alt="analysis-2030265_1280" /></a>
				
			</figure>

		
	
	
	<div class="post-content">
		<div class="post-content-inner">

							<div class="post-date-wrap">
					<time class="post-date entry-date updated" datetime="2019-07-22">
                                                                                                                                                                                                <span class="month">July</span>
                                                                                                    <span class="day">22</span>
                                                                                                    <span class="year">2019</span>
                                                                                            					</time>
				</div>
			
							 <h2 class="post-title entry-title"><a href="http://www.forwardthinkingscience.co.uk/5-chemistry-study-tips/">5 Chemistry Study Tips</a> </h2>			
							<p class="post-meta entry-meta">
											<span class="post-author"><span class="author vcard"><a class="url fn n" href="http://www.forwardthinkingscience.co.uk/author/admin/" rel="author">admin</a></span></span>
					
											 <span class="post-category"><a href="http://www.forwardthinkingscience.co.uk/category/chemistry/" rel="tag" class="term-chemistry">Chemistry</a></span>					
																
									</p>
				<!-- /post-meta -->
			
			
			<div class="entry-content">

				
				
			</div><!-- /.entry-content -->

			
		</div>
		<!-- /.post-content-inner -->
	</div>
	<!-- /.post-content -->
	
</article>
<!-- /.post -->


<article id="post-246" class="post clearfix post-246 type-post status-publish format-standard has-post-thumbnail hentry category-physics has-post-title has-post-date has-post-category has-post-tag has-post-comment has-post-author   cat-4">
	
            <a href="http://www.forwardthinkingscience.co.uk/5-physics-study-tips/" data-post-permalink="yes" style="display: none;"></a>
    
	
	
	
		
			<figure class="post-image  clearfix">

									<a href="http://www.forwardthinkingscience.co.uk/5-physics-study-tips/"><img loading="lazy" src="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/07/geometry-1044090_1280-1024x674-400x300.jpg" width="400" height="300" class=" wp-post-image wp-image-250" alt="geometry-1044090_1280" srcset="http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/07/geometry-1044090_1280-1024x674-400x300.jpg 400w, http://www.forwardthinkingscience.co.uk/wp-content/uploads/2019/07/geometry-1044090_1280-1024x674-7x5.jpg 7w" sizes="(max-width: 400px) 100vw, 400px" /></a>
				
			</figure>

		
	
	
	<div class="post-content">
		<div class="post-content-inner">

							<div class="post-date-wrap">
					<time class="post-date entry-date updated" datetime="2019-07-22">
                                                                                                                                                                                                <span class="month">July</span>
                                                                                                    <span class="day">22</span>
                                                                                                    <span class="year">2019</span>
                                                                                            					</time>
				</div>
			
							 <h2 class="post-title entry-title"><a href="http://www.forwardthinkingscience.co.uk/5-physics-study-tips/">5 Physics Study Tips</a> </h2>			
							<p class="post-meta entry-meta">
											<span class="post-author"><span class="author vcard"><a class="url fn n" href="http://www.forwardthinkingscience.co.uk/author/admin/" rel="author">admin</a></span></span>
					
											 <span class="post-category"><a href="http://www.forwardthinkingscience.co.uk/category/physics/" rel="tag" class="term-physics">Physics</a></span>					
																
									</p>
				<!-- /post-meta -->
			
			
			<div class="entry-content">

				
				
			</div><!-- /.entry-content -->

			
		</div>
		<!-- /.post-content-inner -->
	</div>
	<!-- /.post-content -->
	
</article>
<!-- /.post -->
        </div><!-- .builder-posts-wrap -->
                    </div>
    <!-- /module post -->

    <!-- module buttons -->
    <div  class="module module-buttons tb_5g05422 small outline circle   wow fadeInDown">
	        	<div class="module-buttons">
                            <div class="module-buttons-item  buttons-horizontal">
		    			<a href="http://www.forwardthinkingscience.co.uk/blog/" class="ui builder_button green" >
		    		    			<span>More Blog</span>
		    		    			</a>
		                    </div>
                    </div>
    </div>
    <!-- /module buttons -->
	        </div>
	    	</div>
		    </div>
	    <!-- /row_inner -->
	</div>
	<!-- /module_row -->
		<!-- module_row -->
	<div   data-anchor="testimonials" class="themify_builder_row module_row clearfix fullcover tb_section-testimonials module_row_6 themify_builder_27_row module_row_27-6 tb_de5c0de">
	    <div class="builder_row_cover"></div>	    <div class="row_inner col_align_top" >
			<div  class="module_column tb-column col3-1 first tb_27_column module_column_0 module_column_27-6-0 tb_0661edc" style="width: 4.6%">
	    	    	</div>
		<div  class="module_column tb-column col3-1 middle tb_27_column module_column_1 module_column_27-6-1 tb_2656dc5" style="width: 84%">
	    	    	        <div class="tb-column-inner">
		    <!-- module text -->
<div  class="module module-text tb_4269419  repeat  ">
            <div  class="tb_text_wrap">
    <h2>Testimonials</h2>    </div>
</div>
<!-- /module text -->
    <!-- module divider -->
    <div  class="module module-divider tb_43742ce solid   divider-custom divider-center" style="border-width: 1px;border-color: #000000;width: 250px;">
	            </div>
    <!-- /module divider -->
    <div class="tb_slider_loader"></div>
    <div  class="module clearfix themify_builder_slider_wrap module-testimonial-slider tb_2a428b2  image-top   ">
	                <ul class="themify_builder_slider"
	    data-id="tb_2a428b2"
            data-visible="1"
            data-mob-visible="0"
            data-scroll="1" 
            data-auto-scroll="7"
            data-speed="1"
            data-wrap="yes"
            data-arrow="yes"
            data-pagination="yes"
            data-effect="scroll" 
            data-height="variable"
            data-pause-on-hover="resume"
            data-play-controller="no"
            data-horizontal=""
            >
                        <li class="post">
            <div class="testimonial-item" >
                	

                
                <div class="testimonial-content">
                                            <h3 class="testimonial-title">Help Was Immediate</h3>
                                        						<div class="testimonial-entry-content">
 							<p>I done a crash course in national 5 biology and didn’t understand it that well. I tried memorising the facts but still got low marks in tests. Then I went to Forward Thinking and they explained topics so well and since the class was small, the help was immediate! I think they really helped with my understanding because <strong>I got 91% in my last biology test!</strong></p>						</div>
                                        
                                            <div class="testimonial-author">
                            <div class="person-name">Amman Bains</div>
			    				<span class="person-position">Biology, National 5 </span>
			    			                            </div>
                                    </div>
                <!-- /testimonial-content -->
            </div>
        </li>
            <li class="post">
            <div class="testimonial-item" >
                	

                
                <div class="testimonial-content">
                                            <h3 class="testimonial-title">Helped Me Understand</h3>
                                        						<div class="testimonial-entry-content">
 							<p>The tutors at Forward Thinking helped me understand equations in chemistry. It started to make a lot more sense after my tutor broke down the process and guided me through each step. <strong>I achieved 95% in my last test!</strong></p>						</div>
                                        
                                            <div class="testimonial-author">
                            <div class="person-name">Simran</div>
			    				<span class="person-position">Chemistry, Higher</span>
			    			                            </div>
                                    </div>
                <!-- /testimonial-content -->
            </div>
        </li>
            <li class="post">
            <div class="testimonial-item" >
                	

                
                <div class="testimonial-content">
                                            <h3 class="testimonial-title">I have better understanding</h3>
                                        						<div class="testimonial-entry-content">
 							<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atqulores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. </p>						</div>
                                        
                                            <div class="testimonial-author">
                            <div class="person-name">Albert Einstein</div>
			    				<span class="person-position">Physics, Advanced Higher</span>
			    			                            </div>
                                    </div>
                <!-- /testimonial-content -->
            </div>
        </li>
            </ul>
    </div>
            <!-- module buttons -->
    <div  class="module module-buttons tb_40af983 small outline circle   wow fadeInDown">
	        	<div class="module-buttons">
                            <div class="module-buttons-item  buttons-horizontal">
		    			<a href="#Contactus" class="ui builder_button green" >
		    		    			<span>Book Now</span>
		    		    			</a>
		                    </div>
                    </div>
    </div>
    <!-- /module buttons -->
	        </div>
	    	</div>
		<div  class="module_column tb-column col3-1 last tb_27_column module_column_2 module_column_27-6-2 tb_72709f5" style="width: 5%">
	    	    	</div>
		    </div>
	    <!-- /row_inner -->
	</div>
	<!-- /module_row -->
		<!-- module_row -->
	<div   data-anchor="Contactus" class="themify_builder_row module_row clearfix fullcover tb_section-Contactus module_row_8 themify_builder_27_row module_row_27-8 tb_ef90708">
	    <div class="builder_row_cover"></div>	    <div class="row_inner col_align_middle"   data-basecol="2" data-col_tablet="column-full" data-col_mobile="column-full">
			<div  class="module_column tb-column col4-2 first tb_27_column module_column_0 module_column_27-8-0 tb_2c5bf8c" style="width: 46%" >
	    	    	        <div class="tb-column-inner">
		    <!-- module text -->
<div  class="module module-text tb_98188ec  repeat  ">
            <div  class="tb_text_wrap">
    <h2>Contact Us</h2>    </div>
</div>
<!-- /module text -->
<!-- module text -->
<div  class="module module-text tb_15b958f  repeat  ">
            <div  class="tb_text_wrap">
    <p>If you would like to hire us for tutoring or have any questions, please get in touch. You can call us or email us directly or drop by to have a chat. We are here to help in whatever way we can.</p>    </div>
</div>
<!-- /module text -->
	<div  class="themify_builder_sub_row module_subrow clearfix sub_row_8-0-2 tb_313fc97">
	    	    <div class="subrow_inner gutter-none col_align_top"   data-basecol="2" data-col_mobile="column-full">
			<div style="width:63%;" class="sub_column module_column col2-1 first sub_column_post_27 sub_column_8-0-2-0 tb_a2e4d32"> 
	    	    	        <div class="tb-column-inner">
		    <!-- module text -->
<div  class="module module-text tb_2bce5c3  repeat  ">
            <div  class="tb_text_wrap">
    <h4><u>Info</u></h4>
    </div>
</div>
<!-- /module text -->
<!-- module text -->
<div  class="module module-text tb_fda6f58  repeat  ">
            <div  class="tb_text_wrap">
    <p><a href="tel:0141 230 5917"><i class="fa fa-phone"></i> 0141 230 5917</a><a href="mailto:info@forwardthinkingscience.co.uk"><br /><i class="fa fa-envelope"></i> info@forwardthinkingscience.co.uk</a></p>
    </div>
</div>
<!-- /module text -->
	        </div>
	    	</div>
		<div style="width:37%;" class="sub_column module_column col2-1 last sub_column_post_27 sub_column_8-0-2-1 tb_8268fb0" > 
	    	    	        <div class="tb-column-inner">
		    	        </div>
	    	</div>
		    </div>
	</div><!-- /themify_builder_sub_row -->
		        </div>
	    	</div>
		<div  class="module_column tb-column col4-2 last tb_27_column module_column_1 module_column_27-8-1 tb_3588711" style="width: 50.8%">
	    	    	        <div class="tb-column-inner">
		    <script type="text/javascript">
									var id ="contact-css";
									if(document.getElementById(id)===null){
									    var link = document.createElement("link");
									    link.rel="stylesheet";
									    link.type="text/css";
									    link.id=id;
									    link.href="http://www.forwardthinkingscience.co.uk/wp-content/plugins/builder-contact/assets/style.min.css?ver=1.3.1";
									    document.body.appendChild(link);
									}
							</script>    <!-- module contact -->
    <div  id="contact-27-8-1-0" class="module module-contact contact-27-8-1-0 contact-style3  ">
        <!--insert-->
        
        
        <form action="http://www.forwardthinkingscience.co.uk/wp-admin/admin-ajax.php" class="builder-contact" id="contact-27-8-1-0-form" method="post">
            <div class="contact-message"></div>

            <div class="builder-contact-fields">
                <div class="builder-contact-field builder-contact-field-name builder-contact-text-field" data-order="">
                    <label class="control-label" for="contact-27-8-1-0-contact-name"><span class="tb-label-span">Your Name </span><span class="required">*</span></label>
                    <div class="control-input">
                        <input type="text" name="contact-name" placeholder="" id="contact-27-8-1-0-contact-name" value="" class="form-control" required />
                    </div>
                </div>

                <div class="builder-contact-field builder-contact-field-email builder-contact-text-field" data-order="">
                    <label class="control-label" for="contact-27-8-1-0-contact-email"><span class="tb-label-span">Your Email </span><span class="required">*</span></label>
                    <div class="control-input">
                        <input type="text" name="contact-email" placeholder="" id="contact-27-8-1-0-contact-email" value="" class="form-control" required />
                    </div>
                </div>

                                    <div class="builder-contact-field builder-contact-field-subject builder-contact-text-field" data-order="">
                        <label class="control-label" for="contact-27-8-1-0-contact-subject"><span class="tb-label-span">Subject </span><span class="required">*</span></label>
                        <div class="control-input">
                            <input type="text" name="contact-subject" placeholder="" id="contact-27-8-1-0-contact-subject" value="" class="form-control" required />
                        </div>
                    </div>
                
	                            <div class="builder-contact-field builder-contact-field-message builder-contact-textarea-field" data-order="">
                    <label class="control-label" for="contact-27-8-1-0-contact-message"><span class="tb-label-span">Message </span><span class="required">*</span></label>
                    <div class="control-input">
                        <textarea name="contact-message" placeholder="" id="contact-27-8-1-0-contact-message" rows="8" cols="45" class="form-control" required></textarea>
                    </div>
                </div>
	            
                                                    				
                
				
                
                <div class="builder-contact-field builder-contact-field-send" data-order="10000">
                    <div class="control-input builder-contact-field-send-right">
                        <button type="submit" class="btn btn-primary"> <i class="fa fa-cog fa-spin"></i> Send </button>
                    </div>
                </div>
            </div>
            <script type="text/html" class="builder-contact-form-data">YTo3OntzOjY6InNlbmR0byI7czozMzoiaW5mb0Bmb3J3YXJkdGhpbmtpbmdzY2llbmNlLmNvLnVrIjtzOjE1OiJkZWZhdWx0X3N1YmplY3QiO3M6MDoiIjtzOjExOiJzdWNjZXNzX3VybCI7czowOiIiO3M6OToicG9zdF90eXBlIjtzOjA6IiI7czoxMToicG9zdF9hdXRob3IiO3M6MDoiIjtzOjIwOiJzdWNjZXNzX21lc3NhZ2VfdGV4dCI7czoyNDoiTWVzc2FnZSBzZW50LiBUaGFuayB5b3UuIjtzOjE3OiJjb250YWN0X3NlbnRfZnJvbSI7czowOiIiO30=</script>
            <script type="text/javascript">
				// To load orders instantly, even don't wait for document ready
				(function($){
					var mylist = $('#contact-27-8-1-0').first().find('.builder-contact-fields'),
                                            listitems = mylist.children('div').get();

					listitems.sort(function (a, b) {
						var compA = $(a).attr('data-order') ? parseInt( $(a).attr('data-order') ) : $(a).index(),
                                                    compB = $(b).attr('data-order') ? parseInt( $(b).attr('data-order') ) : $(b).index();
						return ( compA < compB ) ? -1 : ( compA > compB ) ? 1 : 0;
					});
					$.each(listitems, function (idx, itm) {
						mylist.append(itm);
					});
				})(jQuery);
			</script>
        </form>

            </div>
    <!-- /module contact -->
	        </div>
	    	</div>
		    </div>
	    <!-- /row_inner -->
	</div>
	<!-- /module_row -->
		<!-- module_row -->
	<div   class="themify_builder_row module_row clearfix repeat fullwidth module_row_9 themify_builder_27_row module_row_27-9 tb_98099a4 hide-mobile">
	    	    <div class="row_inner col_align_top" >
			<div  class="module_column tb-column col3-1 first tb_27_column module_column_0 module_column_27-9-0 tb_4bf26bd">
	    	    	        <div class="tb-column-inner">
		    <!-- module text -->
<div  class="module module-text tb_e2eb462  repeat  ">
            <div  class="tb_text_wrap">
    <p><a href="http://www.forwardthinkingscience.co.uk/" target="_blank" rel="noopener">© Forward Thinking 2019 </a></p>
    </div>
</div>
<!-- /module text -->
	        </div>
	    	</div>
		<div  class="module_column tb-column col3-1 middle tb_27_column module_column_1 module_column_27-9-1 tb_1dabbf8 repeat" >
	    	    	        <div class="tb-column-inner">
		    <!-- module widget -->
<div  class="module module-widget tb_b0d70f8  repeat ">
	<div class="widget themify-social-links"><ul class="social-links horizontal">
							<li class="social-link-item facebook font-icon icon-medium">
								<a href="https://www.facebook.com/forwardthinkingscience/" ><i class="fa fa-facebook" ></i>  </a>
							</li>
							<!-- /themify-link-item -->
							<li class="social-link-item instagram font-icon icon-medium">
								<a href="https://www.instagram.com/forwardthinkingscience/" ><i class="fa fa-instagram" ></i>  </a>
							</li>
							<!-- /themify-link-item -->
							<li class="social-link-item youtube font-icon icon-medium">
								<a href="https://www.youtube.com/channel/UCV3QZR2lOUdXeZvXCwQAQ4w" ><i class="fa fa-youtube-play" ></i>  </a>
							</li>
							<!-- /themify-link-item --></ul></div></div><!-- /module widget -->	        </div>
	    	</div>
		<div  class="module_column tb-column col3-1 last tb_27_column module_column_2 module_column_27-9-2 tb_e1f2cdb repeat" >
	    	    	        <div class="tb-column-inner">
		    <!-- module text -->
<div  class="module module-text tb_4j1j440  repeat  ">
            <div  class="tb_text_wrap">
    <p><a href="https://www.facebook.com/LooqStudio/" target="_blank" rel="noopener">Site designed by LOOQ </a></p>
    </div>
</div>
<!-- /module text -->
	        </div>
	    	</div>
		    </div>
	    <!-- /row_inner -->
	</div>
	<!-- /module_row -->
		<!-- module_row -->
	<div   class="themify_builder_row module_row clearfix repeat fullwidth module_row_10 themify_builder_27_row module_row_27-10 tb_j2ig522 hide-desktop hide-tablet">
	    	    <div class="row_inner col_align_top" >
			<div  class="module_column tb-column col-full first tb_27_column module_column_0 module_column_27-10-0 tb_rpu1620 repeat" >
	    	    	        <div class="tb-column-inner">
		    <!-- module widget -->
<div  class="module module-widget tb_o2rj022  repeat ">
	<div class="widget themify-social-links"><ul class="social-links horizontal">
							<li class="social-link-item facebook font-icon icon-medium">
								<a href="https://www.facebook.com/forwardthinkingscience/" ><i class="fa fa-facebook" ></i>  </a>
							</li>
							<!-- /themify-link-item -->
							<li class="social-link-item instagram font-icon icon-medium">
								<a href="https://www.instagram.com/forwardthinkingscience/" ><i class="fa fa-instagram" ></i>  </a>
							</li>
							<!-- /themify-link-item -->
							<li class="social-link-item youtube font-icon icon-medium">
								<a href="https://www.youtube.com/channel/UCV3QZR2lOUdXeZvXCwQAQ4w" ><i class="fa fa-youtube-play" ></i>  </a>
							</li>
							<!-- /themify-link-item --></ul></div></div><!-- /module widget --><!-- module text -->
<div  class="module module-text tb_cpm6222  repeat  ">
            <div  class="tb_text_wrap">
    <p><a href="http://www.forwardthinkingscience.co.uk/" target="_blank" rel="noopener">© Forward Thinking 2019 </a></p>    </div>
</div>
<!-- /module text -->
<!-- module text -->
<div  class="module module-text tb_3fcd033  repeat  ">
            <div  class="tb_text_wrap">
    <p><a href="https://www.facebook.com/LooqStudio/" target="_blank" rel="noopener">Site designed by LOOQ </a></p>
    </div>
</div>
<!-- /module text -->
	        </div>
	    	</div>
		    </div>
	    <!-- /row_inner -->
	</div>
	<!-- /module_row -->
	</div>



				
				
				<!-- comments -->
								<!-- /comments -->

			</div>
			<!-- /.post-content -->

			</div><!-- /.type-page -->
		
				
			</div>
	<!-- /content -->
    
	
	

</div>
<!-- /layout-container -->

			</div><!-- /body -->

			
		</div><!-- /#pagewrap -->

		
		<!-- SCHEMA BEGIN --><script type="application/ld+json">[{"@context":"https:\/\/schema.org","@type":"WebPage","mainEntityOfPage":{"@type":"WebPage","@id":"http:\/\/www.forwardthinkingscience.co.uk\/"},"headline":"Home","datePublished":"2018-12-25T17:01:23+00:00","dateModified":"2018-12-25T17:01:23+00:00","description":""},{"@context":"https:\/\/schema.org","@type":"Article","mainEntityOfPage":{"@type":"WebPage","@id":"http:\/\/www.forwardthinkingscience.co.uk\/5-biology-study-tips\/"},"headline":"5 Biology Study Tips","datePublished":"2019-07-22T16:25:26+00:00","dateModified":"2019-07-22T16:25:26+00:00","author":{"@type":"Person","name":"admin"},"publisher":{"@type":"Organization","name":"","logo":{"@type":"ImageObject","url":"","width":0,"height":0}},"description":"Lorem ipsum diam cras dictum justo posuere ad erat nibh potenti ullamcorper aenean netus, velit curabitur pharetra luctus vestibulum at est netus pellentesque mi tempus etiam egestas elementum aliquam. Molestie habitant pretium non lobortis suspendisse odio lacus netus, ultricies malesuada amet a aliquam porttitor tempor aliquet a, curabitur consequat nulla proin ad morbi ultrices vulputate [&hellip;]","image":{"@type":"ImageObject","url":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/uploads\/2019\/07\/dna-3539309_1280-1024x512.jpg","width":1024,"height":512}},{"@context":"https:\/\/schema.org","@type":"Article","mainEntityOfPage":{"@type":"WebPage","@id":"http:\/\/www.forwardthinkingscience.co.uk\/5-chemistry-study-tips\/"},"headline":"5 Chemistry Study Tips","datePublished":"2019-07-22T16:20:08+00:00","dateModified":"2019-07-22T16:20:08+00:00","author":{"@type":"Person","name":"admin"},"publisher":{"@type":"Organization","name":"","logo":{"@type":"ImageObject","url":"","width":0,"height":0}},"description":"Lorem ipsum inceptos turpis malesuada gravida ipsum aenean in pulvinar facilisis dapibus ut commodo dolor dictumst eleifend, himenaeos fames eros leo justo interdum congue et class velit suscipit vivamus mauris etiam litora felis aliquet mauris ligula etiam porttitor semper facilisis auctor platea morbi ante interdum, cursus justo platea pharetra facilisis urna torquent tristique metus suscipit. [&hellip;]","image":{"@type":"ImageObject","url":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/uploads\/2019\/07\/analysis-2030265_1280-1024x682.jpg","width":1024,"height":682}},{"@context":"https:\/\/schema.org","@type":"Article","mainEntityOfPage":{"@type":"WebPage","@id":"http:\/\/www.forwardthinkingscience.co.uk\/5-physics-study-tips\/"},"headline":"5 Physics Study Tips","datePublished":"2019-07-22T15:16:03+00:00","dateModified":"2019-07-22T15:16:03+00:00","author":{"@type":"Person","name":"admin"},"publisher":{"@type":"Organization","name":"","logo":{"@type":"ImageObject","url":"","width":0,"height":0}},"description":"Lorem ipsum rutrum ut conubia enim massa vitae ante ut nam lacus, amet potenti primis praesent sociosqu quam augue taciti vivamus. Vulputate habitasse quisque mattis ultrices tempor varius ligula luctus, fames nam magna scelerisque a egestas fames feugiat, senectus dictumst donec vehicula non pharetra vitae sit dictum justo eleifend habitant. At lorem neque eu erat [&hellip;]","image":{"@type":"ImageObject","url":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/uploads\/2019\/07\/geometry-1044090_1280-1024x674.jpg","width":1024,"height":674}}]</script><!-- /SCHEMA END -->		<!-- wp_footer -->
		

<!-- Instagram Feed JS -->
<script type="text/javascript">
var sbiajaxurl = "http://www.forwardthinkingscience.co.uk/wp-admin/admin-ajax.php";
</script>
<script type='text/javascript' id='themify-main-script-js-extra'>
/* <![CDATA[ */
var themify_vars = {"version":"4.8.1","url":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/themes\/themify-ultra\/themify","wp":"5.5.3","map_key":null,"bing_map_key":null,"includesURL":"http:\/\/www.forwardthinkingscience.co.uk\/wp-includes\/","isCached":null,"commentUrl":"","minify":{"css":{"themify-icons":1,"lightbox":1,"main":1,"themify-builder-style":1},"js":{"backstretch.themify-version":1,"bigvideo":1,"themify.dropdown":1,"themify-tiles":1,"themify.mega-menu":1,"sliderPro.helpers":1,"themify.builder.script":1,"themify.scroll-highlight":1,"themify-youtube-bg":1,"themify-ticks":1}},"media":{"css":{"wp-mediaelement":{"src":"http:\/\/www.forwardthinkingscience.co.uk\/wp-includes\/js\/mediaelement\/wp-mediaelement.min.css","v":false},"mediaelement":{"src":"http:\/\/www.forwardthinkingscience.co.uk\/wp-includes\/js\/mediaelement\/mediaelementplayer-legacy.min.css","v":"4.2.13-9993131"}},"_wpmejsSettings":"var _wpmejsSettings = {\"pluginPath\":\"\\\/wp-includes\\\/js\\\/mediaelement\\\/\",\"classPrefix\":\"mejs-\",\"stretching\":\"responsive\"};","js":{"mediaelement-core":{"src":"http:\/\/www.forwardthinkingscience.co.uk\/wp-includes\/js\/mediaelement\/mediaelement-and-player.min.js","v":"4.2.13-9993131","extra":{"before":[false,"var mejsL10n = {\"language\":\"en\",\"strings\":{\"mejs.download-file\":\"Download File\",\"mejs.install-flash\":\"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\\\/\\\/get.adobe.com\\\/flashplayer\\\/\",\"mejs.fullscreen\":\"Fullscreen\",\"mejs.play\":\"Play\",\"mejs.pause\":\"Pause\",\"mejs.time-slider\":\"Time Slider\",\"mejs.time-help-text\":\"Use Left\\\/Right Arrow keys to advance one second, Up\\\/Down arrows to advance ten seconds.\",\"mejs.live-broadcast\":\"Live Broadcast\",\"mejs.volume-help-text\":\"Use Up\\\/Down Arrow keys to increase or decrease volume.\",\"mejs.unmute\":\"Unmute\",\"mejs.mute\":\"Mute\",\"mejs.volume-slider\":\"Volume Slider\",\"mejs.video-player\":\"Video Player\",\"mejs.audio-player\":\"Audio Player\",\"mejs.captions-subtitles\":\"Captions\\\/Subtitles\",\"mejs.captions-chapters\":\"Chapters\",\"mejs.none\":\"None\",\"mejs.afrikaans\":\"Afrikaans\",\"mejs.albanian\":\"Albanian\",\"mejs.arabic\":\"Arabic\",\"mejs.belarusian\":\"Belarusian\",\"mejs.bulgarian\":\"Bulgarian\",\"mejs.catalan\":\"Catalan\",\"mejs.chinese\":\"Chinese\",\"mejs.chinese-simplified\":\"Chinese (Simplified)\",\"mejs.chinese-traditional\":\"Chinese (Traditional)\",\"mejs.croatian\":\"Croatian\",\"mejs.czech\":\"Czech\",\"mejs.danish\":\"Danish\",\"mejs.dutch\":\"Dutch\",\"mejs.english\":\"English\",\"mejs.estonian\":\"Estonian\",\"mejs.filipino\":\"Filipino\",\"mejs.finnish\":\"Finnish\",\"mejs.french\":\"French\",\"mejs.galician\":\"Galician\",\"mejs.german\":\"German\",\"mejs.greek\":\"Greek\",\"mejs.haitian-creole\":\"Haitian Creole\",\"mejs.hebrew\":\"Hebrew\",\"mejs.hindi\":\"Hindi\",\"mejs.hungarian\":\"Hungarian\",\"mejs.icelandic\":\"Icelandic\",\"mejs.indonesian\":\"Indonesian\",\"mejs.irish\":\"Irish\",\"mejs.italian\":\"Italian\",\"mejs.japanese\":\"Japanese\",\"mejs.korean\":\"Korean\",\"mejs.latvian\":\"Latvian\",\"mejs.lithuanian\":\"Lithuanian\",\"mejs.macedonian\":\"Macedonian\",\"mejs.malay\":\"Malay\",\"mejs.maltese\":\"Maltese\",\"mejs.norwegian\":\"Norwegian\",\"mejs.persian\":\"Persian\",\"mejs.polish\":\"Polish\",\"mejs.portuguese\":\"Portuguese\",\"mejs.romanian\":\"Romanian\",\"mejs.russian\":\"Russian\",\"mejs.serbian\":\"Serbian\",\"mejs.slovak\":\"Slovak\",\"mejs.slovenian\":\"Slovenian\",\"mejs.spanish\":\"Spanish\",\"mejs.swahili\":\"Swahili\",\"mejs.swedish\":\"Swedish\",\"mejs.tagalog\":\"Tagalog\",\"mejs.thai\":\"Thai\",\"mejs.turkish\":\"Turkish\",\"mejs.ukrainian\":\"Ukrainian\",\"mejs.vietnamese\":\"Vietnamese\",\"mejs.welsh\":\"Welsh\",\"mejs.yiddish\":\"Yiddish\"}};"]}},"mediaelement-migrate":{"src":"http:\/\/www.forwardthinkingscience.co.uk\/wp-includes\/js\/mediaelement\/mediaelement-migrate.min.js","v":false,"extra":""}}},"scrollTo":null};
var tbLocalScript = {"ajaxurl":"http:\/\/www.forwardthinkingscience.co.uk\/wp-admin\/admin-ajax.php","isAnimationActive":"1","isParallaxActive":"1","isScrollEffectActive":"1","isStickyScrollActive":"1","animationInviewSelectors":[".module.wow",".module_row.wow",".builder-posts-wrap > .post.wow",".module.module-pro-image"],"backgroundSlider":{"autoplay":5000},"animationOffset":"100","videoPoster":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/themes\/themify-ultra\/themify\/themify-builder\/img\/blank.png","backgroundVideoLoop":"yes","builder_url":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/themes\/themify-ultra\/themify\/themify-builder","framework_url":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/themes\/themify-ultra\/themify","version":"4.8.1","fullwidth_support":"1","fullwidth_container":"body","loadScrollHighlight":"1","addons":{"contact":{"selector":".module-contact","js":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/plugins\/builder-contact\/assets\/scripts.min.js","external":"var BuilderContact = {\"admin_url\":\"http:\\\/\\\/www.forwardthinkingscience.co.uk\\\/wp-admin\\\/admin-ajax.php\"};","ver":"1.3.1"}},"breakpoints":{"tablet_landscape":[769,"1280"],"tablet":[681,"768"],"mobile":"680"},"ticks":{"tick":30,"ajaxurl":"http:\/\/www.forwardthinkingscience.co.uk\/wp-admin\/admin-ajax.php","postID":27},"cf_api_url":"http:\/\/www.forwardthinkingscience.co.uk\/?tb_load_cf=","emailSub":"Check this out!"};
var themifyScript = {"lightbox":{"lightboxSelector":".themify_lightbox","lightboxOn":true,"lightboxContentImages":false,"lightboxContentImagesSelector":"","theme":"pp_default","social_tools":false,"allow_resize":true,"show_title":false,"overlay_gallery":false,"screenWidthNoLightbox":600,"deeplinking":false,"contentImagesAreas":"","gallerySelector":".gallery-icon > a","lightboxGalleryOn":true},"lightboxContext":"body"};
var tbScrollHighlight = {"fixedHeaderSelector":"#headerwrap.fixed-header","speed":"900","navigation":"#main-nav, .module-menu .ui.nav","scrollOffset":"-5","scroll":"internal"};
/* ]]> */
</script>
<script type='text/javascript' defer="defer" src='http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/themify/js/main.min.js?ver=4.8.1' id='themify-main-script-js'></script>
<script type='text/javascript' src='http://www.forwardthinkingscience.co.uk/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' defer="defer" src='http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/themify/js/themify.sidemenu.min.js?ver=2.1.4' id='slide-nav-js'></script>
<script type='text/javascript' id='theme-script-js-extra'>
/* <![CDATA[ */
var themifyScript = {"themeURI":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/themes\/themify-ultra","lightbox":{"lightboxSelector":".themify_lightbox","lightboxOn":true,"lightboxContentImages":false,"lightboxContentImagesSelector":"","theme":"pp_default","social_tools":false,"allow_resize":true,"show_title":false,"overlay_gallery":false,"screenWidthNoLightbox":600,"deeplinking":false,"contentImagesAreas":"","gallerySelector":".gallery-icon > a","lightboxGalleryOn":true},"lightboxContext":"#pagewrap","fixedHeader":"fixed-header","sticky_header":"","ajax_nonce":"fa9d4aed39","ajax_url":"http:\/\/www.forwardthinkingscience.co.uk\/wp-admin\/admin-ajax.php","smallScreen":"760","resizeRefresh":"250","parallaxHeader":"1","loadingImg":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/themes\/themify-ultra\/images\/loading.gif","maxPages":"0","currentPage":"1","pageLoaderEffect":"","autoInfinite":"auto","bufferPx":"50","infiniteURL":"0","scrollToNewOnLoad":"scroll","resetFilterOnLoad":"reset","fullPageScroll":"","shop_masonry":"no","tiledata":{"grids":{"post":{"1":["AAAA"],"2":["BBCC","BBCC"],"3":["DD.."],"4":[".EEF",".EEF"],"5":["DD..","BBCC","BBCC"],"6":[".EEF",".EEF","BBCC","BBCC"],"7":[".EEF",".EEF","DD.."],"8":[".EEF",".EEF","DD..","AAAA"],"9":[".EEF",".EEF","DD..","BBCC","BBCC"],"10":[".EEF",".EEF","DD..","MMNN","MMPP"],"11":[".EEF",".EEF","DD..","MMNN","MMPP","AAAA"],"12":[".EEF",".EEF","DD..","MMNN","MMPP","BBCC","BBCC"],"13":[".EEF",".EEF","DD..","MMNN","MMPP","LSRR","LSRR"]},"mobile":["AA",".."]},"default_grid":"post","small_screen_grid":"mobile","breakpoint":800,"padding":5,"full_width":false,"animate_init":false,"animate_resize":true,"animate_template":false},"responsiveBreakpoints":{"tablet_landscape":"1280","tablet":"768","mobile":"680"}};
/* ]]> */
</script>
<script type='text/javascript' defer="defer" src='http://www.forwardthinkingscience.co.uk/wp-content/themes/themify-ultra/js/themify.script.min.js?ver=2.1.4' id='theme-script-js'></script>
<script type='text/javascript' src='http://www.forwardthinkingscience.co.uk/wp-includes/js/comment-reply.min.js?ver=5.5.3' id='comment-reply-js'></script>
<script type='text/javascript' src='http://www.forwardthinkingscience.co.uk/wp-includes/js/wp-embed.min.js?ver=5.5.3' id='wp-embed-js'></script>
<script type='text/javascript' id='sb_instagram_scripts-js-extra'>
/* <![CDATA[ */
var sb_instagram_js_options = {"font_method":"svg","resized_url":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/uploads\/sb-instagram-feed-images\/","placeholder":"http:\/\/www.forwardthinkingscience.co.uk\/wp-content\/plugins\/instagram-feed\/img\/placeholder.png"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.forwardthinkingscience.co.uk/wp-content/plugins/instagram-feed/js/sbi-scripts.min.js?ver=2.5.4' id='sb_instagram_scripts-js'></script>
	</body>
</html>
/*This file was exported by "Export WP Page to Static HTML" plugin which created by ReCorp (https://myrecorp.com) */